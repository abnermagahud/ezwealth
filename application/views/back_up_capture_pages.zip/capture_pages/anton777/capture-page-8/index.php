<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0"><!-- Bootstrap -->
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/library/bootstrap/css/bootstrap.css" media="screen" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/library/bootstrap/css/bootstrap-responsive.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/css/custom-style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/css/media-queries.css" rel="stylesheet" />
<p><input id="baseurl" name="baseurl" type="hidden" value="http://www.ezwealthpages.com/" /> <!-- Part 1: Wrap all page content here --></p>

<div id="wrap">
<div class="container">
<div class="content_wrapper">
<div class="pull-right"><strong style="color:#fff;">Antonia Aves | anthonyjune_aves@yahoo.com | 09473538168</strong></div>
<input id="capture_page_id" name="capture_page_id" type="hidden" value="8" />
<div class="content_holder"><!-- Begin content -->
<div class="row-fluid">
<div class="span7 form" style="text-align:center;">
<div class="row-fluid">
<div class="span12"><img alt="Logo" height="223" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/images/logo.jpg" width="539" /></div>
<!-- //End span12 --></div>
<!-- //End row-fluid -->

<div class="row-fluid">
<div class="span12"><!-- Form -->
<div class="row-fluid" style="background:#534848;">
<div class="span12 form-title">
<h1 style="text-align:center; color:#FFF;">GET STARTED TODAY!</h1>

<h1>&nbsp;</h1>
</div>
<!-- //End span12 --></div>
<!-- //End row-fluid -->

<div class="row-fluid" style="background:#fc4df2;">
<form method="post">
<div class="span12">
<div class="rowpush" style="height:20px;">&nbsp;</div>
<input id="email" name="email" placeholder="Enter Your Email" style="width:85%;" type="text" /> <input id="member_id" name="member_id" type="hidden" value="77" />
<div class="rowpush" style="height:20px;">&nbsp;</div>

<p><input id="btn_submit1" onclick="sendEmail()" type="button" value="SIGN UP NOW" /></p>

<div class="rowpush" style="height:20px;">&nbsp;</div>
</div>
<!-- //End span12 --></form>
</div>
<!-- //End row-fluid --><!-- //End Form --></div>
<!-- //End span12 --></div>
<!-- //End row-fluid --></div>
<!-- //End span7 -->

<div class="span5"><img alt="Plum" height="460" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/images/plum.jpg" width="400" /></div>
<!-- //End span9 --></div>
<!-- //End row-fluid --></div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container --><!-- //End Form -->

<div class="rowpush" style="height:40px;">&nbsp;</div>

<div class="container">
<div class="content_wrapper">
<div class="content_holder"><!-- Begin content -->
<div class="row-fluid">
<div class="span3"><img alt="Plum" height="300" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/images/testimonial-1.jpg" width="228" /></div>

<div class="span3"><img alt="Plum" height="300" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/images/testimonial-2.jpg" width="228" /></div>

<div class="span3"><img alt="Plum" height="300" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/images/testimonial-3.jpg" width="228" /></div>

<div class="span3"><img alt="Plum" height="300" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/images/testimonial-4.jpg" width="228" /></div>
</div>
</div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container -->

<div id="push">&nbsp;</div>
</div>
<!--//End Wrap-->

<div id="footer">
<div class="container">&nbsp;</div>
<!--//End Container--></div>
<!--//End Footer--><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/js/jquery-1.9.1.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/library/bootstrap/js/bootstrap.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-8/js/script.js"></script>