<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0"><!-- Bootstrap -->
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/library/bootstrap/css/bootstrap.css" media="screen" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/library/bootstrap/css/bootstrap-responsive.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/css/custom-style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/css/media-queries.css" rel="stylesheet" />
<p><input id="baseurl" name="baseurl" type="hidden" value="http://www.ezwealthpages.com/" /> <!-- Part 1: Wrap all page content here --></p>

<div id="wrap">
<div class="container" style="background:#000;">
<div class="content_wrapper">
<div class="pull-right"><strong style="color:#fff;">Antonia Aves | anthonyjune_aves@yahoo.com | 09473538168</strong></div>
<input id="capture_page_id" name="capture_page_id" type="hidden" value="1" />
<div class="content_holder"><!-- Begin content --><img alt="Work From Home" border="0" height="98" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/images/work-from-home.gif" style="text-align:center;" width="661" /></div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container -->

<div class="rowpush" style="height:20px;">&nbsp;</div>

<div class="container">
<div class="content_wrapper">
<div class="content_holder"><!-- Begin content -->
<div class="row-fluid form">
<div class="span7">&nbsp;</div>

<div class="span5" style="background:#00a3d6; text-align:center; padding:40px;">
<h3>SIGN UP NOW</h3>

<form method="post">
<div class="rowpush" style="height:40px;">&nbsp;</div>
<input id="email" name="email" style="width:90%;" type="text" /> <input id="member_id" name="member_id" type="hidden" value="77" />
<div class="rowpush" style="height:20px;">&nbsp;</div>

<p style="color:#FFF;font-size:20px;">ENTER YOUR BEST EMAIL</p>

<div class="rowpush" style="height:20px;">&nbsp;</div>
<input id="btn_submit1" onclick="sendEmail()" type="button" value="SUBMIT" />&nbsp;</form>
</div>
</div>
</div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container -->

<div class="rowpush" style="height:60px;">&nbsp;</div>

<div class="container">
<div class="content_wrapper">
<div class="content_holder"><!-- Begin content -->
<div class="row-fluid" style="background:url(http://www.ezwealthpages.com//assets/capture_page_assets/capture-page-1/images/white-bg.png); padding:20px;">
<div class="span12">
<h2 style="text-align:center;line-height:1;"><span style="color:#0e940e;">MAKE EXTRA MONEY</span> FOR YOUR FAMILY</h2>
</div>
</div>
</div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container -->

<div id="push">&nbsp;</div>
</div>
<!--//End Wrap-->

<div id="footer">
<div class="container">
<div class="content_wrapper">
<div class="content_holder"><!-- Begin content --></div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!--//End Container--></div>
<!--//End Footer--><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/js/jquery-1.9.1.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/library/bootstrap/js/bootstrap.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-1/js/script.js"></script>