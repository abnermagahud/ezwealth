<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0"><!-- Bootstrap -->
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/library/bootstrap/css/bootstrap.css" media="screen" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/library/bootstrap/css/bootstrap-responsive.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/css/custom-style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/css/media-queries.css" rel="stylesheet" />
<p><input id="baseurl" name="baseurl" type="hidden" value="http://www.ezwealthpages.com/" /> <!-- Part 1: Wrap all page content here --></p>

<div id="wrap">
<div class="pull-right"><strong style="color:#fff;">Antonia Aves | anthonyjune_aves@yahoo.com | 09473538168</strong></div>
<input id="capture_page_id" name="capture_page_id" type="hidden" value="5" />
<div class="container" style="background:#ff85fe;"><img alt="Weight Loss Formula" height="96" src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/images/weightloss-formula.jpg" width="771" /></div>
<!-- //End Container -->

<div class="rowpush" style="height:40px;">&nbsp;</div>

<div class="container">
<div class="content_wrapper">
<div class="content_holder"><!-- Begin content -->
<div class="row-fluid">
<div class="span5" style="text-align:center;">&nbsp;</div>
<!-- //End span9 -->

<div class="span7 form" style="text-align:center;">
<div class="row-fluid">
<div class="span12">
<h1>Want to look HOT?</h1>

<h2 style="color:#FFF; background:#af93fc;">LOSE UP TO 10 POUNDS IN 10 DAYS</h2>
</div>
<!-- //End span12 --></div>
<!-- //End row-fluid -->

<div class="rowpush" style="height:20px;">&nbsp;</div>

<div class="row-fluid" style="background:#534848;">
<div class="span12 form-title">
<h1 style="text-align:center; color:#FFF;">GET STARTED TODAY!</h1>

<h1>&nbsp;</h1>
</div>
<!-- //End span12 --></div>
<!-- //End row-fluid -->

<div class="row-fluid" style="background:#ff3c02;">
<div class="span12">
<form method="post">
<div class="rowpush" style="height:20px;">&nbsp;</div>
<input id="email" name="email" placeholder="Enter Your Email" style="width:85%;" type="text" /> <input id="member_id" name="member_id" type="hidden" value="77" />
<div class="rowpush" style="height:20px;">&nbsp;</div>

<p><input id="btn_submit1" onclick="sendEmail()" type="button" value="SIGN UP NOW" /></p>

<div class="rowpush" style="height:20px;">&nbsp;</div>
</form>
</div>
<!-- //End span12 --></div>
<!-- //End row-fluid --></div>
<!-- //End span9 --></div>
<!-- //End row-fluid --></div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container --> <!-- //End Form -->

<div class="rowpush" style="height:60px;">&nbsp;</div>

<div id="push">&nbsp;</div>
</div>
<!--//End Wrap-->

<div id="footer" style="background:#8aff9d;">
<div class="container">
<p style="text-align:center; font-size:60px; margin-top:30px; color:#ff0000;line-height:1;">ACT NOW, BEFORE ITS GONE!</p>
</div>
<!--//End Container--></div>
<!--//End Footer--><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/js/jquery-1.9.1.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/library/bootstrap/js/bootstrap.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-5/js/script.js"></script>