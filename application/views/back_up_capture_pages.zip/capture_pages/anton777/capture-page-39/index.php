<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0"><!-- Bootstrap -->
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/library/bootstrap/css/bootstrap.css" media="screen" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/library/bootstrap/css/bootstrap-responsive.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/css/custom-style.css" rel="stylesheet" />
<link href="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/css/media-queries.css" rel="stylesheet" />
<p><input id="baseurl" name="baseurl" type="hidden" value="http://www.ezwealthpages.com/" /></p>

<div class="pull-right"><strong style="color:#000;">Antonia Aves | anthonyjune_aves@yahoo.com | 09473538168</strong></div>

<p><input id="capture_page_id" name="capture_page_id" type="hidden" value="39" /> <!-- Part 1: Wrap all page content here --></p>

<div id="wrap">
<div class="container">
<div class="content_wrapper" style="height:50px;">
<div class="content_holder"><!-- Begin content --></div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container -->

<div class="container">
<div class="content_wrapper">
<div class="content_holder"><!-- Begin content -->
<div class="row-fluid">
<div class="span6">&nbsp;</div>
<!-- //End span6 -->

<div class="span6"><img src="images/logo.jpg" />
<div class="rowpush" style="height:50px;">&nbsp;</div>

<div class="form">
<form method="post">
<p class="form-heading">LEAVE YOUR DETAILS FOR MORE INFO</p>
<br />
<input id="member_id" name="member_id" type="hidden" value="77" /> <input class="span12" id="email" name="email" placeholder="Email" type="text" /><br />
<br />
<input class="span12" id="contact_num" name="contact_num" placeholder="Contact Number" type="text" /><br />
<br />
<input id="btn_submit1" onclick="sendEmail()" type="button" value="SUBMIT" />&nbsp;</form>
</div>
<!-- //End form --></div>
<!-- //End span6 --></div>
<!-- //End row-fluid --></div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!-- //End Container -->

<div id="push">&nbsp;</div>
</div>
<!--//End Wrap-->

<div id="footer">
<div class="container">
<div class="content_wrapper">
<div class="content_holder"><!-- Begin content --></div>
<!-- //End Content Holder --></div>
<!-- //End Content Wrapper --></div>
<!--//End Container--></div>
<!--//End Footer--><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/js/jquery-1.9.1.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/library/bootstrap/js/bootstrap.min.js"></script><script src="http://www.ezwealthpages.com/assets/capture_page_assets/capture-page-39/js/script.js"></script>